# This file will contain the logic for loading your Gemma TFLite models.
# It's updated to reflect the specific model types you're using.

import tensorflow as tf

def load_gemma_model(model_path):
    """
    Loads a Gemma TFLite model and allocates tensors.
    
    Args:
        model_path (str): The path to the .tflite or .bin file.

    Returns:
        A tf.lite.Interpreter instance.
    """
    try:
        interpreter = tf.lite.Interpreter(model_path=model_path)
        interpreter.allocate_tensors()
        print(f"Successfully loaded model from {model_path}")
        return interpreter
    except Exception as e:
        print(f"Error loading model from {model_path}: {e}")
        print("Please ensure the model file is in the correct path.")
        return None

# Placeholder functions for your two brains.
# We will map the actual files to these functions based on your choice.

def load_logic_brain_model(path):
    """Loads the 'Logic' brain model (formerly Qwen, now a Gemma model)."""
    print("Loading Logic Brain...")
    return load_gemma_model(path)

def load_art_tonality_brain_model(path):
    """Loads the 'Art/Tonality' brain model (Gemma)."""
    print("Loading Art/Tonality Brain...")
    return load_gemma_model(path)
