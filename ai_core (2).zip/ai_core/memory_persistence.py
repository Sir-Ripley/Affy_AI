# This file abstracts the persistence of the 'memory_archive'.
# By centralizing memory access here, you can easily swap the backend 
# from a simple file to a cloud database (like Firestore, Redis, or a SQL DB)
# without changing the core AI logic in QuantumEgoArbiter.

# For now, we will simulate persistence with a simple text file.
# In a real cloud/device scenario, this would be a proper database connection.
MEMORY_FILE = "memory_archive.txt"

def get_memory_archive():
    """Retrieves the entire memory archive from persistence."""
    print("Getting memory archive from persistence...")
    try:
        with open(MEMORY_FILE, "r") as f:
            # Assuming one floating point number per line
            return [float(line.strip()) for line in f.readlines()]
    except FileNotFoundError:
        return []

def get_latest_memories(limit=50):
    """Retrieves the N most recent memories."""
    archive = get_memory_archive()
    return archive[-limit:]

def add_to_memory_archive(new_state):
    """Adds a new state to the persistent memory archive."""
    print(f"Adding new state to persistent memory: {new_state}")
    with open(MEMORY_FILE, "a") as f:
        f.write(f"{new_state}
")

