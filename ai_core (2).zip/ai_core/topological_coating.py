import numpy as np
import tensorflow as tf
from tensorflow.keras.layers import Layer

# Base-12 Conversion Utilities
def to_duodecimal(decimal_array, precision=10):
    """Converts a numpy array of decimals (0-1) to base-12 strings."""
    if np.any((decimal_array < 0) | (decimal_array > 1)):
        # Normalize if not in [0, 1] range, though the assumption is they are.
        # This is a fallback and might indicate an issue upstream.
        decimal_array = (decimal_array - np.min(decimal_array)) / (np.max(decimal_array) - np.min(decimal_array))

    duodecimal_repr = []
    for number in decimal_array.flatten():
        b12_str = "0."
        for _ in range(precision):
            number *= 12
            digit = int(number)
            b12_str += np.base_repr(digit, base=12)
            number -= digit
        duodecimal_repr.append(b12_str)
    return np.array(duodecimal_repr).reshape(decimal_array.shape)

def from_duodecimal(duodecimal_array):
    """Converts a numpy array of base-12 strings back to decimals."""
    decimal_repr = []
    for b12_str in duodecimal_array.flatten():
        b12_str = b12_str.split('.')[-1] # Get fractional part
        decimal_val = 0.0
        for i, digit in enumerate(b12_str, 1):
            decimal_val += int(digit, 12) / (12**i)
        decimal_repr.append(decimal_val)
    return np.array(decimal_repr).reshape(duodecimal_array.shape)

# Topological Layer for Neural Network
class TopologicalLayer(Layer):
    """
    A custom Keras layer that introduces a 'topological' transformation.
    This is a conceptual implementation. The actual 'topology' would
    depend on the specific geometric/structural properties you want to model.
    """
    def __init__(self, units=32, activation=None, **kwargs):
        super(TopologicalLayer, self).__init__(**kwargs)
        self.units = units
        self.activation = tf.keras.activations.get(activation)

    def build(self, input_shape):
        self.kernel = self.add_weight(
            shape=(input_shape[-1], self.units),
            initializer="glorot_uniform",
            trainable=True,
            name="topological_kernel",
        )
        self.bias = self.add_weight(
            shape=(self.units,), initializer="zeros", trainable=True, name="topological_bias"
        )
        super(TopologicalLayer, self).build(input_shape)

    def call(self, inputs):
        # 1. Standard linear transformation
        linear_transform = tf.matmul(inputs, self.kernel) + self.bias

        # 2. Conceptual 'Topological' transformation
        # This could be a complex, non-linear function that models structural relationships.
        # For this example, we'll use a sinusoidal projection as a stand-in for a
        # more complex topological function. It creates periodic activations,
        # which can be thought of as a simple form of "folding" the data space.
        topological_transform = tf.sin(linear_transform) + tf.cos(linear_transform)

        if self.activation is not None:
            return self.activation(topological_transform)
        return topological_transform

# Differentiable Duodecimal Loss
@tf.function
def duodecimal_loss(y_true, y_pred, precision=10):
    """
    A custom loss function that operates in a conceptual base-12 space.
    It encourages the network to produce outputs that are 'cleanly' representable
    in base-12, effectively creating a quantized output space.
    """
    # 1. Convert predictions to a base-12 friendly format.
    # We simulate this by scaling the prediction to an integer range
    # representing the base-12 digits and then finding the 'error' in that space.
    y_pred_b12_scaled = y_pred * (12**precision)
    y_true_b12_scaled = y_true * (12**precision)

    # 2. Quantization error
    # This penalizes predictions that are not close to an integer in the scaled space.
    # The idea is to make the output 'snap' to representable base-12 fractions.
    quantization_error = tf.square(y_pred_b12_scaled - tf.round(y_pred_b12_scaled))

    # 3. Standard reconstruction error (in the scaled space)
    reconstruction_error = tf.square(y_true_b12_scaled - y_pred_b12_scaled)

    # Combine the two errors. The alpha parameter balances reconstruction vs. quantization.
    alpha = 0.1
    loss = (1 - alpha) * reconstruction_error + alpha * quantization_error
    return tf.reduce_mean(loss)
