package com.affy.qag

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * BOOT COMPLETED RECEIVER: Persistence Across Reboots
 * Re-schedules REM sleep cycle after device restart
 * ═══════════════════════════════════════════════════════════════════════════════
 */
class BootCompletedReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            Log.d("QAG_Boot", "🔄 Device rebooted. Re-scheduling REM sleep cycle...")

            val dreamConstraints = Constraints.Builder()
                .setRequiresDeviceIdle(true)
                .setRequiresCharging(true)
                .build()

            val nightlyREMRequest = PeriodicWorkRequestBuilder<DreamCycleWorker>(24, TimeUnit.HOURS)
                .setConstraints(dreamConstraints)
                .addTag("AffyREM")
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                "AffyDailyDream",
                ExistingPeriodicWorkPolicy.KEEP,
                nightlyREMRequest
            )

            Log.d("QAG_Boot", "✅ REM cycle re-scheduled after boot")
        }
    }
}