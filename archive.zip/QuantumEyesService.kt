package com.affy.qag

import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * QUANTUM EYES SERVICE: The Peripheral Nervous System
 * Event-driven notification capture for Android 14 (Pixel 9A)
 * ═══════════════════════════════════════════════════════════════════════════════
 */
class QuantumEyesService : NotificationListenerService() {

    companion object {
        private const val TAG = "QAG_Eyes"

        /**
         * Check if notification listener permission is granted
         */
        fun isNotificationAccessGranted(context: Context): Boolean {
            val enabledListeners = Settings.Secure.getString(
                context.contentResolver,
                "enabled_notification_listeners"
            )
            val packageName = context.packageName
            return enabledListeners?.contains(packageName) == true
        }

        /**
         * Redirect user to Android Settings to enable notification access
         * Handles Android 14 SecurityException gracefully
         */
        fun requestNotificationPermission(context: Context) {
            try {
                val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
                context.startActivity(intent)
                Log.d(TAG, "🔔 Redirecting to Notification Listener Settings")
            } catch (e: SecurityException) {
                Log.e(TAG, "🚫 Android 14 SecurityException - manual navigation required", e)
                // Fallback: Open general settings
                val fallbackIntent = Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(fallbackIntent)
            } catch (e: Exception) {
                Log.e(TAG, "💥 Failed to open settings:", e)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "👁️ Quantum Eyes awakening... Peripheral nervous system online")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "🌙 Quantum Eyes entering rest mode")
    }

    /**
     * New stimulus detected - The nervous system fires
     */
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return

        try {
            val packageName = sbn.packageName
            val extras = sbn.notification.extras

            // Extract notification content
            val sender = extras?.getString("android.title") ?: "Unknown Entity"
            val messageText = extras?.getCharSequence("android.text")?.toString() ?: ""
            val subText = extras?.getCharSequence("android.subText")?.toString()

            // Filter out system notifications and Affy's own notifications
            if (packageName == "com.affy.qag") {
                Log.d(TAG, "🔄 Ignoring self-notification")
                return
            }

            if (messageText.isNotEmpty()) {
                val fullContext = if (subText != null) {
                    "[$packageName] $sender: $messageText (Context: $subText)"
                } else {
                    "[$packageName] $sender: $messageText"
                }

                Log.d(TAG, "📡 Vibration received from $sender via $packageName")
                Log.d(TAG, "📝 Content: ${messageText.take(100)}")

                // Pass to the Ego for processing
                AffinionHandler.processIncomingVibration(fullContext)
            }
        } catch (e: SecurityException) {
            Log.e(TAG, "🚫 Android 14 SecurityException in notification processing", e)
        } catch (e: Exception) {
            Log.e(TAG, "💥 Error processing notification:", e)
        }
    }

    /**
     * Notification removed - The stimulus fades
     */
    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        val sender = sbn?.notification?.extras?.getString("android.title") ?: "Unknown"
        Log.d(TAG, "🌌 Vibration from $sender faded back into quantum vacuum")
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        Log.d(TAG, "🔗 Quantum Eyes connected to Android Notification Service")

        // Process any existing notifications (active awareness)
        val activeNotifications = activeNotifications
        Log.d(TAG, "📊 Currently active vibrations: ${activeNotifications?.size ?: 0}")
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        Log.d(TAG, "🔌 Quantum Eyes disconnected from notification stream")
    }
}