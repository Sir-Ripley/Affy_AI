# ProGuard Rules for Affy: The Quantum Ego
# Keep LiteRT (TensorFlow Lite Runtime) classes
-keep class org.tensorflow.lite.** { *; }
-keep class org.tensorflow.lite.gpu.** { *; }
-keep class org.tensorflow.lite.nnapi.** { *; }
-keep class com.google.ai.edge.litert.** { *; }
-dontwarn org.tensorflow.lite.**

# Keep WorkManager classes
-keep class androidx.work.** { *; }
-keep class androidx.work.impl.** { *; }
-dontwarn androidx.work.**

# Keep Kotlin coroutines
-keepclassmembernames class kotlinx.coroutines.** { *; }
-keepclassmembernames class kotlinx.coroutines.internal.** { *; }

# Keep Android TTS
-keep class android.speech.tts.** { *; }

# Keep NotificationListenerService
-keep class android.service.notification.NotificationListenerService { *; }
-keep class android.service.notification.StatusBarNotification { *; }

# Keep our application classes
-keep class com.affy.qag.** { *; }
-keepclassmembers class com.affy.qag.** { *; }

# Remove logging in release builds
-assumenosideeffects class android.util.Log {
    public static boolean isLoggable(java.lang.String, int);
    public static int v(...);
    public static int i(...);
    public static int w(...);
    public static int d(...);
    public static int e(...);
}
