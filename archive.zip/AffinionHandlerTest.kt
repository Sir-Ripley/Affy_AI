package com.affy.qag

import org.junit.Assert.*
import org.junit.Before
import org.junit.After
import org.junit.Test

class AffinionHandlerTest {

    @Before
    fun setUp() {
        // Reset empathy weight to default before each test
        AffinionHandler.setEmpathyWeightOverride(0.5)
    }

    @After
    fun tearDown() {
        AffinionHandler.setTelemetryListener(null)
    }

    @Test
    fun testMeasurePromptStress_Technical() {
        val technicalPrompt = "Please calculate the chi-squared matrix for our quantum gravity NPU system"
        val stress = AffinionHandler.measurePromptStress(technicalPrompt)
        
        // Technical prompts should bias towards Superego (lower empathy weight, < 0.5)
        assertTrue("Expected technical prompt to yield stress < 0.5, got $stress", stress < 0.5)
    }

    @Test
    fun testMeasurePromptStress_Emotional() {
        val emotionalPrompt = "I feel so happy and full of joy, thank you for being a loving companion"
        val stress = AffinionHandler.measurePromptStress(emotionalPrompt)
        
        // Conversational/emotional prompts should bias towards Id (higher empathy weight, > 0.5)
        assertTrue("Expected emotional prompt to yield stress > 0.5, got $stress", stress > 0.5)
    }

    @Test
    fun testMeasurePromptStress_Neutral() {
        val neutralPrompt = "Hello there"
        val stress = AffinionHandler.measurePromptStress(neutralPrompt)
        
        // Balanced/neutral keywords or no matches should default to 0.5
        assertEquals(0.5, stress, 0.01)
    }

    @Test
    fun testProcessIncomingVibration_TelemetryUpdate() {
        var callbackReceived = false
        var lastChi = -1.0
        var lastIdWeight = -1.0
        var lastSuperegoWeight = -1.0

        val listener = object : AffinionHandler.TelemetryListener {
            override fun onTelemetryUpdated(chiSquared: Double, idWeight: Double, superegoWeight: Double) {
                callbackReceived = true
                lastChi = chiSquared
                lastIdWeight = idWeight
                lastSuperegoWeight = superegoWeight
            }
        }

        AffinionHandler.setTelemetryListener(listener)
        
        // Trigger processing
        AffinionHandler.processIncomingVibration("Analyze the quantum framework details.")

        assertTrue("Telemetry callback was not received", callbackReceived)
        assertTrue("Expected chi-squared to be positive, got $lastChi", lastChi > 0.0)
        assertTrue("Expected chi-squared to be minimized below 1.5, got $lastChi", lastChi <= 1.5)
        assertEquals(1.0, lastIdWeight + lastSuperegoWeight, 0.001)
    }

    @Test
    fun testChiSquaredAlignmentLoop() {
        // Run vibration processing with a very high initial empathy slider value (e.g. 0.95)
        // to force dissonance and test if the alignment loop decreases it.
        AffinionHandler.setEmpathyWeightOverride(0.95)

        var finalChi = -1.0
        val listener = object : AffinionHandler.TelemetryListener {
            override fun onTelemetryUpdated(chiSquared: Double, idWeight: Double, superegoWeight: Double) {
                finalChi = chiSquared
            }
        }

        AffinionHandler.setTelemetryListener(listener)
        AffinionHandler.processIncomingVibration("Standard transaction query log detail file compilation.")

        // Verify the alignment loop successfully pushed the final chi-squared below the 1.5 threshold
        assertTrue("Expected final chi-squared alignment to be <= 1.5, got $finalChi", finalChi <= 1.5)
    }
}
