package com.affy.qag

import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * NATIVE TOOL SAMPLER: Termux IPC Loopback & Local Storage Gateway
 * Bridges Android Kotlin layer directly to Termux PRoot Python math kernels & RAG
 * ═══════════════════════════════════════════════════════════════════════════════
 */
class NativeToolSampler(private val vaultRoot: File = File("/sdcard")) {

    companion object {
        private const val TAG = "QAG_ToolSampler"
        private const val IPC_URL = "http://127.0.0.1:8080/exec"
    }

    fun executeTool(toolName: String, argsJson: String = ""): String {
        val args = if (argsJson.isBlank()) JSONObject() else JSONObject(argsJson)
        return when (toolName) {
            "read_local_file" -> readLocalFile(args.optString("relative_path", ""))
            "list_directory" -> listDirectory(args.optString("relative_path", ""))
            "exec_termux" -> execTermux(args.optString("script", ""), args.optJSONObject("payload") ?: JSONObject())
            "sync_downloads" -> execTermux("sync_downloads", JSONObject())
            "query_memory" -> execTermux("query_rag", JSONObject().put("query", args.optString("query", "")))
            "affinity_ignition" -> execTermux("affinity_ignition", JSONObject())
            "calculate_v_qag" -> execTermux("calculate_v_qag", args.optJSONObject("payload") ?: JSONObject())
            else -> JSONObject().put("error", "Unknown tool: $toolName").toString()
        }
    }

    private fun readLocalFile(relativePath: String): String {
        val file = File(vaultRoot, relativePath)
        if (!file.exists() || !file.canonicalPath.startsWith(vaultRoot.canonicalPath)) {
            return JSONObject().put("error", "Access denied or file not found").toString()
        }
        return JSONObject().put("path", relativePath).put("content", file.readText()).toString()
    }

    private fun listDirectory(relativePath: String): String {
        val dir = File(vaultRoot, relativePath)
        if (!dir.exists() || !dir.isDirectory) {
            return JSONObject().put("error", "Invalid directory").toString()
        }
        val fileArray = JSONArray()
        dir.listFiles()?.forEach { f ->
            fileArray.put(JSONObject().put("name", f.name).put("is_dir", f.isDirectory).put("size", f.length()))
        }
        return JSONObject().put("files", fileArray).toString()
    }

    fun execTermux(scriptName: String, payload: JSONObject = JSONObject()): String {
        return try {
            val url = URL(IPC_URL)
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "application/json")
            conn.doOutput = true
            conn.connectTimeout = 4000
            conn.readTimeout = 12000

            val body = JSONObject().put("script", scriptName).put("data", payload).toString()
            OutputStreamWriter(conn.outputStream).use {
                it.write(body)
                it.flush()
            }

            if (conn.responseCode == 200) {
                BufferedReader(InputStreamReader(conn.inputStream)).use { it.readText() }
            } else {
                Log.w(TAG, "Termux IPC non-200 code: ${conn.responseCode}")
                JSONObject().put("error", "HTTP ${conn.responseCode}").toString()
            }
        } catch (e: Exception) {
            Log.e(TAG, "IPC bridge failure:", e)
            JSONObject().put("error", "IPC bridge failure: ${e.message}").toString()
        }
    }
}
