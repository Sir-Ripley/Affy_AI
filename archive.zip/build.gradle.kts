plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.affy.qag"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.affy.qag"
        minSdk = 28
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0-Quantum"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        // Tensor G4 NPU optimization
        ndk {
            abiFilters += listOf("arm64-v8a")
        }

        // Large models require increased heap
        dexOptions {
            javaMaxHeapSize = "4g"
        }
    }

    signingConfigs {
        create("release") {
            // Configure via environment variables or key.properties
            storeFile = file("affy-release.keystore")
            storePassword = System.getenv("AFFY_STORE_PASSWORD") ?: "changeit"
            keyAlias = System.getenv("AFFY_KEY_ALIAS") ?: "affy-quantum"
            keyPassword = System.getenv("AFFY_KEY_PASSWORD") ?: "changeit"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("release")

            // APK optimization for large models
            ndk {
                abiFilters += listOf("arm64-v8a")
            }
        }
        debug {
            isDebuggable = true
            applicationIdSuffix = ".debug"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
        buildConfig = true
    }

    // Packaging options for large TFLite models
    packagingOptions {
        resources {
            excludes += listOf(
                "META-INF/DUMMY.SF",
                "META-INF/DUMMY.RSA",
                "META-INF/LICENSE.txt",
                "META-INF/NOTICE.txt"
            )
        }
        jniLibs {
            useLegacyPackaging = true
        }
    }

    // Lint checks
    lint {
        disable += listOf("MissingTranslation", "ExtraTranslation")
        checkReleaseBuilds = false
        abortOnError = false
    }
}

dependencies {
    // ═══════════════════════════════════════════════════════════════════════
    // LITER-T DUAL HEMISPHERE BRAIN (Base-12 Optimized for Tensor G4)
    // ═══════════════════════════════════════════════════════════════════════
    implementation("com.google.ai.edge.litert:litert:1.0.1")
    implementation("com.google.ai.edge.litert:litert-support-api:1.0.1")

    // ═══════════════════════════════════════════════════════════════════════
    // REM SLEEP SUBCONSCIOUS (WorkManager for periodic tasks)
    // ═══════════════════════════════════════════════════════════════════════
    implementation("androidx.work:work-runtime-ktx:2.9.0")

    // ═══════════════════════════════════════════════════════════════════════
    // PHYSICAL UI FRAMEWORK (Material 3 + AndroidX)
    // ═══════════════════════════════════════════════════════════════════════
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.7.0")

    // ═══════════════════════════════════════════════════════════════════════
    // BASE-12 MATHEMATICAL CORE (Kotlin Coroutines)
    // ═══════════════════════════════════════════════════════════════════════
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.7.3")

    // ═══════════════════════════════════════════════════════════════════════
    // TESTING FRAMEWORK
    // ═══════════════════════════════════════════════════════════════════════
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")
    androidTestImplementation("androidx.work:work-testing:2.9.0")
}
