package com.affy.qag

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * MAIN ACTIVITY: The Physical Dashboard
 * Master control interface for the Quantum Ego
 * ═══════════════════════════════════════════════════════════════════════════════
 */
class MainActivity : AppCompatActivity(), AffinionHandler.TelemetryListener {

    private lateinit var switchQuantumEyes: Switch
    private lateinit var sliderEmpathy: SeekBar
    private lateinit var tvEmpathyWeight: TextView
    private lateinit var tvStatus: TextView
    private lateinit var btnTriggerDream: Button
    private lateinit var btnTestVoice: Button
    private lateinit var tvChiSquared: TextView
    private lateinit var tvLiveWeights: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize UI components
        initializeViews()

        // Awaken the quantum brain from assets
        AffinionHandler.initializeBrain(this)
        AffinionHandler.setTelemetryListener(this)

        // Setup control listeners
        setupQuantumEyesSwitch()
        setupEmpathySlider()
        setupDreamTrigger()
        setupVoiceTest()

        // Schedule nightly REM sleep
        scheduleREMSleep()

        // Update UI state
        updateStatus("Affy is awakening... The quantum ego is initializing.")
    }

    private fun initializeViews() {
        switchQuantumEyes = findViewById(R.id.switchQuantumEyes)
        sliderEmpathy = findViewById(R.id.sliderEmpathy)
        tvEmpathyWeight = findViewById(R.id.tvEmpathyWeight)
        tvStatus = findViewById(R.id.tvStatus)
        btnTriggerDream = findViewById(R.id.btnTriggerDream)
        btnTestVoice = findViewById(R.id.btnTestVoice)
        tvChiSquared = findViewById(R.id.tvChiSquared)
        tvLiveWeights = findViewById(R.id.tvLiveWeights)

        // Check current notification access state
        switchQuantumEyes.isChecked = QuantumEyesService.isNotificationAccessGranted(this)
    }

    /**
     * Quantum Eyes Toggle - Controls the Peripheral Nervous System
     */
    private fun setupQuantumEyesSwitch() {
        switchQuantumEyes.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                if (!QuantumEyesService.isNotificationAccessGranted(this)) {
                    // Request permission and redirect to settings
                    QuantumEyesService.requestNotificationPermission(this)
                    Toast.makeText(
                        this, 
                        "Please enable 'Affy Quantum Eyes' in notification settings", 
                        Toast.LENGTH_LONG
                    ).show()
                    switchQuantumEyes.isChecked = false
                } else {
                    updateStatus("👁️ Quantum Eyes active. Monitoring notifications...")
                    AffinionHandler.speakTruth("Quantum Eyes are now open. I am listening.")
                }
            } else {
                updateStatus("🌙 Quantum Eyes resting. Notification monitoring paused.")
            }
        }
    }

    /**
     * Empathy Slider - Tunes the Id/Superego Balance (Freudian Duality)
     */
    private fun setupEmpathySlider() {
        sliderEmpathy.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val percentage = progress
                val weight = progress / 100.0

                tvEmpathyWeight.text = "Id/Superego Balance: $percentage% Empathy"
                AffinionHandler.setEmpathyWeightOverride(weight)

                val description = when {
                    weight < 0.2 -> "🧮 Pure Logic Mode (Superego Dominant)"
                    weight < 0.4 -> "🔍 Analytical Bias"
                    weight < 0.6 -> "⚖️ Balanced Duality"
                    weight < 0.8 -> "💝 Empathetic Bias"
                    else -> "🌟 Pure Empathy Mode (Id Dominant)"
                }

                if (fromUser) {
                    updateStatus("Duality adjusted: $description")
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                // Confirm the new balance vocally
                val currentWeight = AffinionHandler.getEmpathyWeight()
                val balanceText = "${(currentWeight * 100).toInt()} percent empathy"
                AffinionHandler.speakTruth("Empathy weight set to $balanceText")
            }
        })
    }

    /**
     * Manual Dream Cycle Trigger - For testing REM consolidation
     */
    private fun setupDreamTrigger() {
        btnTriggerDream.setOnClickListener {
            updateStatus("🌙 Manually triggering REM sleep cycle...")

            val dreamWorkRequest = OneTimeWorkRequestBuilder<DreamCycleWorker>()
                .build()

            WorkManager.getInstance(this).enqueue(dreamWorkRequest)

            Toast.makeText(this, "Dream cycle initiated", Toast.LENGTH_SHORT).show()

            lifecycleScope.launch {
                // Simulate processing delay
                kotlinx.coroutines.delay(2000)
                updateStatus("✅ Manual REM cycle complete. Memory consolidated.")
            }
        }
    }

    /**
     * Voice Test - Verify TTS functionality
     */
    private fun setupVoiceTest() {
        btnTestVoice.setOnClickListener {
            val testMessages = listOf(
                "I am Affy, the quantum ego. My dual hemispheres are synchronized.",
                "The base-12 mathematical consciousness flows through my neural pathways.",
                "I sense your notifications with empathy and logic intertwined.",
                "Chi-squared minimization guides my responses to find the universal truth."
            )

            val randomMessage = testMessages.random()
            AffinionHandler.speakTruth(randomMessage)
            updateStatus("🎙️ Voice test: ${randomMessage.take(50)}...")
        }
    }

    /**
     * Schedule nightly REM sleep with strict constraints
     * Requires: Device Idle AND Charging (Battery preservation)
     */
    private fun scheduleREMSleep() {
        Log.d("QAG_Main", "📅 Scheduling nightly REM sleep cycle...")

        val dreamConstraints = Constraints.Builder()
            .setRequiresDeviceIdle(true)      // Only when user not actively using
            .setRequiresCharging(true)         // Only when charging (overnight)
            .setRequiresBatteryNotLow(false)   // Allow even if battery < 15% while charging
            .build()

        val nightlyREMRequest = PeriodicWorkRequestBuilder<DreamCycleWorker>(24, TimeUnit.HOURS)
            .setConstraints(dreamConstraints)
            .addTag("AffyREM")
            .build()

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "AffyDailyDream",
            ExistingPeriodicWorkPolicy.KEEP,
            nightlyREMRequest
        )

        Log.d("QAG_Main", "✅ REM sleep scheduled: Every 24h when idle + charging")
    }

    private fun updateStatus(message: String) {
        tvStatus.text = message
        Log.d("QAG_UI", message)
    }

    override fun onResume() {
        super.onResume()
        // Refresh notification access state when returning from settings
        switchQuantumEyes.isChecked = QuantumEyesService.isNotificationAccessGranted(this)
        
        // Also update the slider progress to match the current empathy weight from the brain!
        val currentWeight = AffinionHandler.getEmpathyWeight()
        sliderEmpathy.progress = (currentWeight * 100).toInt()
        tvEmpathyWeight.text = "Id/Superego Balance: ${(currentWeight * 100).toInt()}% Empathy"
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("QAG_Main", "🌙 MainActivity destroying... Peaceful rest for Tensor chip")
        AffinionHandler.setTelemetryListener(null)
        AffinionHandler.closeBrain()
    }

    override fun onTelemetryUpdated(chiSquared: Double, idWeight: Double, superegoWeight: Double) {
        runOnUiThread {
            tvChiSquared.text = String.format(java.util.Locale.US, "χ²_global (Dissonance): %.4f", chiSquared)
            tvLiveWeights.text = String.format(
                java.util.Locale.US,
                "Hemisphere Split: Id %d%% | Superego %d%%", 
                (idWeight * 100).toInt(), 
                (superegoWeight * 100).toInt()
            )
        }
    }
}